var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
const fs = require('fs');

const PORT = 3000;



http.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});

let filePath, editorPath, idd, cell;
let htmlcode=`<!DOCTYPE html>
<html>
  <head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js"></script>
    <style>
      .one {
        border: 1px solid #c3c3c3;
        display: flex;
        flex-direction: column;
      }

      .main {
        border: 5px solid #c3c3c3;
        display: flex;
        flex-direction: row;
      }

      .one div {
        border: 2px solid #c3c3c3;
        width: 45vw;
        height: 33vh;
      }
      .second {
        width: 52vw;
      }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="/socket.io/socket.io.js"></script>
  </head>
  <body>
    <nav
      style="
        z-index: 100;
        height: 5vh;
        position: sticky;
        top: 0vh;
        background-color: black;
      "
    >
      <button id="nbt" style="height: 5vh;" onclick="New()">New</button>
      
      <button style="height: 4.5vh; float: right;" onclick="setAutoSave()">Auto Save Code & O/P</button>
      <input style="height: 3.5vh; width: 3vw; float: right;" type="number" id="AutoSaveInput" value="60" min="0"><font style="color: white; float: right; margin-right: 1vw;">Seconds:</font>
      <button style="height: 4.5vh; float: right;" onclick="setPath()">Set Path</button>
      <input style="height: 3.5vh; float: right;" type="text" id="setPath"><font style="color: white; float: right; margin-right: 1vw;">Path to Editor</font>      
    </nav>

    <script>
let i=0

let min=[]

     
      setTimeout(minimize, 100);
      function minimize() {
        min.forEach((id) => {
          if (id.charAt(0) === "H") {
            document.getElementById("H" + id.substring(2)).style.display =
              "none";
          } else if (id.charAt(0) === "C") {
            console.log("C" + id.substring(2));
            document.getElementById("C" + id.substring(2)).style.display =
              "none";
          } else {
            console.log("J" + id.substring(2));
            document.getElementById("J" + id.substring(2)).style.display =
              "none";
          }
          document.getElementById(id).innerHTML = "+";
        });
      }
      function Delete(button) {
        var buttons = document.getElementsByClassName("del");
        for (var i = 0; i < buttons.length; i++) {
          buttons[i].style.visibility = "hidden";
        }
        var parentElement = button.parentElement.parentElement;
        var parentId = parentElement.id;
        socket.emit("Delete", parentId);
        const elementToRemove = document.getElementById(parentId);
        document.getElementsByClassName(parentId)[0].remove();
        document.getElementsByClassName(parentId)[0].remove();
        elementToRemove.remove();
        setTimeout(function () {
          for (var i = 0; i < buttons.length; i++) {
            buttons[i].style.visibility = "visible";
          }
        }, 100);
      }

      function New() {
        document.getElementById("nbt").style.visibility = "hidden";
        RemoveAceEditors();
        i++;
        data = \`<div class="main" id="\${i}">
  <div class="one"><button class="del" onclick="Delete(this)">Delete</button>
      <label for="">↑↓<input id="EX\${i}" onclick="exch(this)" type="checkbox"> Copy<input id="CP\${i}" onclick="copy(this)" type="checkbox"> HTML <button id="HB\${i}" onclick="Plus(this)" style="float: right;">x</button></label>
    <div id="H\${i}" onkeyup="run(this)"></DiV>
    <label for="">CSS<button id="CB\${i}" onclick="Plus(this)" style="float: right;">-</button></label>
    <div id="C\${i}" onkeyup="run(this)"></DiV>
    <label for="">JS<button id="JB\${i}" onclick="Plus(this)" style="float: right;">-</button></label>
    <div id="J\${i}" onkeyup="run(this)"></DiV>
  </div>
  <iframe id="O\${i}" class="second"></iframe>
  </div>
<br class='\${i}'><br class='\${i}'>\`;
        document.getElementById("new").innerHTML += data;
        console.log("add");
        socket.emit("data", { data: data, i: i });
        setTimeout(InitializeAceEditors, 300, i);
      }
      var socket = io();

      socket.on("connect", function () {
        console.log("Client has connected to the server!");
        socket.emit("idd", i);
      });

      function Plus(e) {
        if (e.innerHTML === "-") {
          if (e.id.charAt(0) === "H") {
            document.getElementById("H" + e.id.substring(2)).style.display =
              "none";
          } else if (e.id.charAt(0) === "C") {
            document.getElementById("C" + e.id.substring(2)).style.display =
              "none";
          } else {
            document.getElementById("J" + e.id.substring(2)).style.display =
              "none";
          }
          e.innerHTML = "+";
          min.push(e.id);
          console.log(min);
          socket.emit("min", min);
        } else {
          if (e.id.charAt(0) === "H") {
            document.getElementById("H" + e.id.substring(2)).style.display =
              "flex";
          } else if (e.id.charAt(0) === "C") {
            document.getElementById("C" + e.id.substring(2)).style.display =
              "flex";
          } else {
            document.getElementById("J" + e.id.substring(2)).style.display =
              "flex";
          }
          let index = min.indexOf(e.id);

          if (index !== -1) {
            min.splice(index, 1);
          }
          socket.emit("min", min);
          e.innerHTML = "-";
        }
      }

      let map = {};

      function RemoveAceEditors(ed) {
        var oneDivs = document.querySelectorAll(".main"); // Select all divs within div.one
        oneDivs.forEach((element) => {
          var id = element.id;

          try {
            editor = ace.edit("H" + id);
            map["H" + id] = editor.getValue();
            editor.destroy("H" + id);

            editor = ace.edit("C" + id);
            console.log(editor.getValue());
            map["C" + id] = editor.getValue();
            editor.destroy("C" + id);

            editor = ace.edit("J" + id);
            console.log(editor.getValue());
            map["J" + id] = editor.getValue();
            editor.destroy("J" + id);
          } catch (error) {
            console.log(error);
          }
        });
      }

      function InitializeAceEditors(ed) {
        var oneDivs = document.querySelectorAll(".main"); // Select all divs within div.one
        oneDivs.forEach((element) => {
          var id = element.id;

          try {
            let output = document.getElementById("O" + id);
            editor = ace.edit("H" + id);
            editor.setTheme("ace/theme/monokai"); // Set a theme
            editor.renderer.setOption("showGutter", true);
            editor.getSession().setMode("ace/mode/html");
            if (map["H" + id] !== undefined) {
              editor.setValue(map["H" + id]);
              output.contentDocument.body.innerHTML = map["H" + id];
            }

            editor = ace.edit("C" + id);
            editor.setTheme("ace/theme/monokai"); // Set a theme
            editor.renderer.setOption("showGutter", true);
            editor.getSession().setMode("ace/mode/css");
            if (map["C" + id] !== undefined) {
              editor.setValue(map["C" + id]);
              output.contentDocument.body.innerHTML +=
                "<style>" + map["C" + id] + "</style>";
            }

            editor = ace.edit("J" + id);
            editor.setTheme("ace/theme/monokai"); // Set a theme
            editor.renderer.setOption("showGutter", true);
            editor.getSession().setMode("ace/mode/javascript");
            if (map["J" + id] !== undefined) {
              editor.setValue(map["J" + id]);
              output.contentWindow.eval(map["J" + id]);
            }
          } catch (error) {
            console.log(error);
          }
        });
        document.getElementById("nbt").style.visibility = "visible";
      }

      function run(e) {
        var id = e.id.substring(1);

        var editor = ace.edit("H" + id);
        let htmlCode = editor.getValue();

        editor = ace.edit("C" + id);
        let cssCode = editor.getValue();

        editor = ace.edit("J" + id);
        let jsCode = editor.getValue();

        let output = document.getElementById("O" + id);

        output.contentDocument.body.innerHTML =
          htmlCode + "<style>" + cssCode + "</style>";
        output.contentWindow.eval(jsCode);
      }
//////////////save
      let autoSave=60000
      function save() {
        const oneDivs = document.querySelectorAll(".main"); // Select all divs within div.one
        var data = {};
        oneDivs.forEach((element) => {
          var id = element.id;
          var editor = ace.edit("H" + id);
          let htmlCode = editor.getValue();

          editor = ace.edit("C" + id);
          let cssCode = editor.getValue();

          editor = ace.edit("J" + id);
          let jsCode = editor.getValue();
          data[id] = { htmlCode: htmlCode, cssCode: cssCode, jsCode: jsCode };
        });
        document.title = "Saved";
        socket.emit("save", data);
      }
      let intervalId = setInterval(save, autoSave);

      document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && (event.key === 's' || event.key === 'S')) {
            event.preventDefault();
            document.title = "Saved";
            save();
        }
      });

      function setAutoSave(){
        autoSave = parseInt(document.getElementById("AutoSaveInput").value) * 1000;
        clearInterval(intervalId);
        intervalId = setInterval(save, autoSave);
        document.title = "Saved";
      }
      
      document.addEventListener('keypress', function(event) {
        document.title = "Un-Save";
      });


//////////////

      let ex = 0;
      let id1 = -1,
        id2 = -1;
      function exch(e) {
        ex++;

        if (ex == 1) {
          id1 = e.id.substring(2);
        }
        if (ex == 2) {
          id2 = e.id.substring(2);
        }
        if (id1 == id2) {
          id1 = -1;
          id2 = -1;
          ex = 0;
          return;
        }
        if (ex == 2) {
          var editor1 = ace.edit("H" + id1);
          let Code1 = editor1.getValue();
          var editor2 = ace.edit("H" + id2);
          let Code2 = editor2.getValue();
          editor2.setValue(Code1);
          editor1.setValue(Code2);

          editor1 = ace.edit("C" + id1);
          Code1 = editor1.getValue();
          editor2 = ace.edit("C" + id2);
          Code2 = editor2.getValue();
          editor2.setValue(Code1);
          editor1.setValue(Code2);

          editor1 = ace.edit("J" + id1);
          Code1 = editor1.getValue();
          editor2 = ace.edit("J" + id2);
          Code2 = editor2.getValue();
          editor2.setValue(Code1);
          editor1.setValue(Code2);

          document.getElementById(\`EX\${id1}\`).checked = false;
          document.getElementById(\`EX\${id2}\`).checked = false;
          try {
            id = id1;

            var editor = ace.edit("H" + id);
            let htmlCode = editor.getValue();

            editor = ace.edit("C" + id);
            let cssCode = editor.getValue();

            editor = ace.edit("J" + id);
            let jsCode = editor.getValue();

            let output = document.getElementById("O" + id);

            output.contentDocument.body.innerHTML =
              htmlCode + "<style>" + cssCode + "</style>";
            output.contentWindow.eval(jsCode);
          } catch (error) {
            console.log(error);
          }
          try {
            id = id2;

            editor = ace.edit("H" + id);
            htmlCode = editor.getValue();

            editor = ace.edit("C" + id);
            cssCode = editor.getValue();

            editor = ace.edit("J" + id);
            jsCode = editor.getValue();

            output = document.getElementById("O" + id);

            output.contentDocument.body.innerHTML =
              htmlCode + "<style>" + cssCode + "</style>";
            output.contentWindow.eval(jsCode);
          } catch (error) {
            console.log(error);
          }
          ex = 0;
          id1 = -1;
          id2 = -1;
          document.title = "Un-Save";
        }
      }

      let cp = 0;
      let id11 = -1,
        id22 = -1;
      function copy(e) {
        console.log("cp");
        cp++;

        if (cp == 1) {
          id11 = e.id.substring(2);
        }
        if (cp == 2) {
          id22 = e.id.substring(2);
        }
        if (id11 == id22) {
          id11 = -1;
          id22 = -1;
          cp = 0;
          return;
        }
        if (cp == 2) {
          var editor1 = ace.edit("H" + id11);
          let Code1 = editor1.getValue();
          var editor2 = ace.edit("H" + id22);
          let Code2 = editor2.getValue();
          editor2.setValue(Code1);

          editor1 = ace.edit("C" + id11);
          Code1 = editor1.getValue();
          editor2 = ace.edit("C" + id22);
          Code2 = editor2.getValue();
          editor2.setValue(Code1);

          editor1 = ace.edit("J" + id11);
          Code1 = editor1.getValue();
          editor2 = ace.edit("J" + id22);
          Code2 = editor2.getValue();
          editor2.setValue(Code1);

          document.getElementById(\`CP\${id11}\`).checked = false;
          document.getElementById(\`CP\${id22}\`).checked = false;
          try {
            id = id22;

            var editor = ace.edit("H" + id);
            let htmlCode = editor.getValue();

            editor = ace.edit("C" + id);
            let cssCode = editor.getValue();

            editor = ace.edit("J" + id);
            let jsCode = editor.getValue();

            let output = document.getElementById("O" + id);

            output.contentDocument.body.innerHTML =
              htmlCode + "<style>" + cssCode + "</style>";
            output.contentWindow.eval(jsCode);
          } catch (error) {
            console.log(error);
          }

          cp = 0;
          id11 = -1;
          id22 = -1;
          document.title = "Un-Save";
        }
      }

//////////////////////////////
  function setPath(){
    if(document.getElementById("setPath").value.length>0){
      clearInterval(intervalId);
      socket.emit("editorGet", document.getElementById("setPath").value);
      document.body.innerHTML="<h1>cunnected!</h1><br><h2>Refresh to continue</h2>"
    }
  }        
    </script>
    <script>
      function runAll() {
        var oneDivs = document.querySelectorAll(".main"); // Select all divs within div.one
        oneDivs.forEach((element) => {
          var id = element.id;

          try {
            let htmlCode = document.getElementById("H" + id).innerHTML;

            let cssCode = document.getElementById("C" + id).innerHTML;//console.log("--->",document.getElementById("C" + id).innerText);


            let jsCode = document.getElementById("J" + id).innerHTML;
            editor = ace.edit("H" + id); // Initialize Ace Editor for each div
            editor.setTheme("ace/theme/monokai"); // Set a theme
            editor.renderer.setOption("showGutter", true);
            editor.getSession().setMode("ace/mode/html");
            editor.setValue(htmlCode);

            editor = ace.edit("C" + id); // Initialize Ace Editor for each div
            editor.setTheme("ace/theme/monokai"); // Set a theme
            editor.renderer.setOption("showGutter", true);
            editor.getSession().setMode("ace/mode/css");
            editor.setValue(cssCode);

            editor = ace.edit("J" + id); // Initialize Ace Editor for each div
            editor.setTheme("ace/theme/monokai"); // Set a theme
            editor.renderer.setOption("showGutter", true);
            editor.getSession().setMode("ace/mode/javascript");
            editor.setValue(jsCode);

            let output = document.getElementById("O" + id);

            output.contentDocument.body.innerHTML =
              htmlCode + "<style>" + cssCode + "</style>";
            output.contentWindow.eval(jsCode);
          } catch (error) {
            console.log(error);
          }
        });
      }
      window.addEventListener('load', function() {
        // Call runAll function when the window has finished loading
        runAll();
      });
    </script>




<div id="new"></div>
  </body>
</html>`






io.on('connection', function (socket) {
  console.log('a user has connected!');


  socket.on('disconnect', function () {
    console.log('user disconnected');
  });

  socket.on('data', function (data) {

    const contentToAppend = data['data'];
    const id = data['i']
    idd = id;
    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return;
      }

      const lines = data.split('\n');

      // Find the second last line
      const secondLastLineIndex = lines.length - 4; // -2 because arrays are 0-based



      for (i = 0; i < lines.length; i++) {


        if (lines[i].substring(0, 6) === "let i=") {
          lines[i] = "let i=" + id;
          break;
        }
      }

      // Append your content to the second last line
      lines[secondLastLineIndex] += contentToAppend;

      // Join the lines back together into a single string
      const modifiedHTML = lines.join('\n');

      // Write the modified content back to the file
      fs.writeFile(filePath, modifiedHTML, (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return;
        }
        console.log('Content appended successfully!');
      });
    });
  })


  socket.on('min', function (min) {

    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return;
      }

      // Split the HTML content into an array of lines
      const lines = data.split('\n');

      for (i = 0; i < lines.length; i++) {


        if (lines[i].substring(0, 8) === "let min=") {
          var temp = ""
          min.forEach((id) => {
            temp += "'" + id + "',";

          });
          lines[i] = `let min=[${temp}]`;

          break;
        }
      }

      const modifiedHTML = lines.join('\n');

      fs.writeFile(filePath, modifiedHTML, (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return;
        }
        console.log('Content appended successfully!');
      });
    });
  })

  socket.on('Delete', function (id) {

    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return;
      }
      const lines = data.split('id="' + id + '"');


      var i = lines[0].length - 1
      for (; i >= 0; i--) {
        if (lines[0].charAt(i) == '<')
          break;
      }
      lines[0] = lines[0].substring(0, i);
      i = 0
      var temp = ("<br class='" + id + "'><br class='" + id + "'>").length;
      for (; i < lines[1].length; i++) {
        if (lines[1].substring(i, i + temp) === "<br class='" + id + "'><br class='" + id + "'>")
          break;
      }
      lines[1] = lines[1].substring(i + temp);
      
      const modifiedHTML = lines[0] + lines[1];

      fs.writeFile(filePath, modifiedHTML, (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return;
        }
        console.log('Content appended successfully!');
      });
    });
  })

  socket.on('save', function (value) {

    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return;
      }
      const lines = data.split('class="main"');

      for (i = 2; i < lines.length; i++) {

        for (j = 0; j < lines[i].length; j++) {
          if (lines[i].substring(j, j + 4) === 'id="') {
            break;
          }
        }
        id = ""
        for (j = j + 4; j < lines[i].length; j++) {
          if (lines[i].charAt(j) === '"') {
            break;
          }
          id += lines[i].charAt(j)
        }
        
        for (; j < lines[i].length; j++) {
          if (lines[i].substring(j, j + 20) === 'onkeyup="run(this)">') {
            break;
          }
        }

        for (end = j; end < lines[i].length; end++) {
          if (lines[i].substring(end, end + 6) === '</DiV>') {
            break;
          }
        }
        lines[i] = lines[i].substring(0, j + 20) + value[id]['htmlCode'] + lines[i].substring(end)

        for (j += 20; j < lines[i].length; j++) {
          if (lines[i].substring(j, j + 20) === 'onkeyup="run(this)">') {
            break;
          }
        }

        for (end = j; end < lines[i].length; end++) {
          if (lines[i].substring(end, end + 6) === '</DiV>') {
            break;
          }
        }
        lines[i] = lines[i].substring(0, j + 20) + value[id]['cssCode'] + lines[i].substring(end)


        for (j += 20; j < lines[i].length; j++) {
          if (lines[i].substring(j, j + 20) === 'onkeyup="run(this)">') {
            break;
          }
        }

        for (end = j; end < lines[i].length; end++) {
          if (lines[i].substring(end, end + 6) === '</DiV>') {
            break;
          }
        }
        lines[i] = lines[i].substring(0, j + 20) + value[id]['jsCode'] + lines[i].substring(end)

      }
      const modifiedHTML = lines.join('class="main"');
      //console.log("-->",modifiedHTML)
      fs.writeFile(filePath, modifiedHTML, (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return;
        }
        //console.log('Content appended successfully!');
      });

    });

  });
  editorPath=""
  socket.on('editorGet', function (pathh) {
    console.log(pathh+"kkkkkkkkkkkkxxxxxxxxxxxxx");
    pathh=pathh.replace(/\\/g, '/')
    console.log(pathh+"kkkkkkkkkkkkxxxxxxxxxxxxx");
    editorPath = pathh;   
    const { exec } = require('child_process');

    // Define the Python script to run
    const pythonScript = 'keyDetect.py';

    // Execute the Python script
    exec(`python ${pythonScript}`, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error executing Python script: ${error}`);
        return;
      }

      console.log(`Python script output:\n${stdout}`);
    });     
  });
  socket.on('idd', function (iddd) {
    idd=iddd;
  });
});

const path = require('path');
////////////////
app.get('/', (req, res) => {
  fs.readdir(path.join(__dirname, 'html_files'), (err, files) => {
    if (err) {
      console.error('Error reading directory:', err);
      return res.status(500).send('Internal Server Error');
    }
    const htmlLinks = files.map(file => `<a href="/view/${file}">${file}</a>
    <a href="/file?operation=delete&fileName=${file}&newFileName="><button>Delete</button></a>
    `).join('<br>');

    const htmlContent = `
      <h1>Available HTML Files:</h1>
      ${htmlLinks}
      <br>
      <form id="form" action="/file" method="get">
        <label for="operation">Operation:</label>
        <select name="operation" id="operation">
          <option value="create">Create File</option>
          <option value="delete">Delete File</option>
          <option value="rename">Rename File</option>
        </select>
        <input type="text" name="fileName" placeholder="File Name">
        <input type="text" name="newFileName" placeholder="New File Name (for rename)">
        <input type="submit" value="Submit">
      </form>
      <script>
  document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission behavior}
    </script>


    `;
    res.send(htmlContent);
  });
});



app.get('/view/:fileName', (req, res) => {
  const fileName = req.params.fileName;
  //const filePath = path.join(__dirname, 'html_files', fileName);
  filePath = path.join(__dirname, 'html_files', fileName);
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      return res.status(500).send('Internal Server Error');
    }
    res.send(data);
  });
});


app.get('/file', (req, res) => {
  const operation = req.query.operation;
  const fileName = req.query.fileName;
  const newFileName = req.query.newFileName;
  const filePath = path.join(__dirname, 'html_files', fileName);
  const newFilePath = path.join(__dirname, 'html_files', newFileName);

  switch (operation) {
    case 'create':

        fs.writeFile(filePath, htmlcode, (err) => {
          if (err) {
            console.error('Error creating file:', err);
            return res.status(500).send('Internal Server Error');
          }
          res.redirect('/');
        });
      

      break;

    case 'delete':
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error('Error deleting file:', err);
          return res.status(500).send('Internal Server Error');
        }
        res.redirect('/');
      });
      break;

    case 'rename':
      fs.rename(filePath, newFilePath, (err) => {
        if (err) {
          console.error('Error renaming file:', err);
          return res.status(500).send('Internal Server Error');
        }
        res.redirect('/');
      });
      break;

    default:
      res.status(400).send('Invalid operation');
  }

});




////////////////////


app.get('/keyDetect', (req, res) => {
  
  // Read the file
  if(editorPath!="")
  fs.readFile(editorPath, 'utf8', (err, data) => {
    setTimeout(() => {
      var n=data.length;
      if (err) {
        console.error(err);
        return;
      }
      var i=0;
      var style=""
      for(;i<n;i++){
        if(data.substring(i,i+7)==="<style>") break;
      }
      i=i+7
      for(;i<n;i++){
        if(data.substring(i,i+8)==="</style>") break;
        style+=data.charAt(i);
      }
      //console.log("style--->"+style)
      i=0;   
      var script=""
      for(;i<n;i++){
        if(data.substring(i,i+8)==="<script>") break;
      }
      i=i+8
      for(;i<n;i++){
        if(data.substring(i,i+9)==="</script>") break;
        script+=data.charAt(i);
      }
      //console.log("script--->"+script)
      i=0
      k=true;
      var html=""
      for(;i<n;i++){
        if(data.substring(i,i+6)==="<body>") break;
      }
      i=i+6
      for(;i<n;i++){
        if(data.substring(i,i+7)==="<style>"||data.substring(i,i+8)==="<script>"){
          i+=7
          k=false
        }
        if(data.substring(i,i+9)==="</script>"||data.substring(i,i+8)==="</style>"){
          i+=8
          k=true; continue;
        }
        if(data.substring(i,i+7)==="</body>") break;
        if(k){
          html+=data.charAt(i);
        }
      }
      //console.log("html--->"+html)
      idd+=1
      //console.log("presssssssssssssssssssssssss",idd)  
      cell=`<div class="main" id="${idd}">
      <div class="one"><button class="del" onclick="Delete(this)">Delete</button>
          <label for="">↑↓<input id="EX${idd}" onclick="exch(this)" type="checkbox"> Copy<input id="CP${idd}" onclick="copy(this)" type="checkbox"> HTML <button id="HB${idd}" onclick="Plus(this)" style="float: right;">x</button></label>
        <div id="H${idd}" onkeyup="run(this)">${html}</DiV>
        <label for="">CSS<button id="CB${idd}" onclick="Plus(this)" style="float: right;">-</button></label>
        <div id="C${idd}" onkeyup="run(this)">${style}</DiV>
        <label for="">JS<button id="JB${idd}" onclick="Plus(this)" style="float: right;">-</button></label>
        <div id="J${idd}" onkeyup="run(this)">${script}</DiV>
      </div>
      <iframe id="O${idd}" class="second"></iframe>
      </div>
    <br class='${idd}'><br class='${idd}'>`; 

    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return;
      }

      const lines = data.split('\n');

      // Find the second last line
      const secondLastLineIndex = lines.length - 4; // -2 because arrays are 0-based



      for (i = 0; i < lines.length; i++) {


        if (lines[i].substring(0, 6) === "let i=") {
          lines[i] = "let i=" + idd;
          break;
        }
      }

      // Append your content to the second last line
      lines[secondLastLineIndex] += cell;

      // Join the lines back together into a single string
      const modifiedHTML = lines.join('\n');

      //Write the modified content back to the file
      fs.writeFile(filePath, modifiedHTML, (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return;
        }
        //console.log('Content appended successfully!');
      });
    });

    res.send("");
  }, 100); 
  });
  
});

app.get('/keyDetect1', (req, res) => {
  //console.log("pressssssssssssssssssss");
  res.send("");
});