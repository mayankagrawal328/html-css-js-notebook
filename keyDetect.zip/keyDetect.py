import keyboard
import requests

url = 'http://localhost:3000/keyDetect'

def on_key_event(e):
    if e.name == 'alt' and e.event_type == keyboard.KEY_DOWN and keyboard.is_pressed('ctrl'):
        response = requests.get(url)
        #print("Ctrl + Alt pressed")

keyboard.hook(on_key_event)

# Keep the script running
keyboard.wait()


